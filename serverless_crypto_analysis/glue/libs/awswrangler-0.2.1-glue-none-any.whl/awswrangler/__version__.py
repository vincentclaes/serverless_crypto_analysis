__title__ = "awswrangler"
__description__ = "Utility belt to handle data on AWS."
__version__ = "0.2.1"
__license__ = "Apache License 2.0"
